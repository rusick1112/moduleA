<?php
include("inc/header.php");
?>

<body class="bg-success">
  <div class="container p-3 text-center">
    <h1 class="mt-3 mb-4 text-white display-1">Ягодкам.Нет</h1>
    <p class="p-1 pt-4 display-6 text-light">
      Наш портал представляет собой подобие на маркетплейс, где вы можете посмотреть на существующие товары, не существующие на нашем сайте и добавить их в несуществующую корзину.
    </p>
  </div>

  <div class="container p-2 mb-5 text-center">
    <a
      href="/auth/"
      class="btn btn-success text-success-emphasis bg-light w-75 p-3 fs-2 rounded-pill fw-bold shadow-lg"
    >
      Пополнить наши ряды
    </a>
    <h2 class="display-4 mt-5 text-white">Закажи прямо сейчас</h2>

    <a href="/products.php" class="btn btn-primary mt-3">Посмотреть товары</a>
  </div>

  <?php
include("inc/footer.php");
?>
</body>

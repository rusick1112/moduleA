<?php
session_start();
include("../inc/header.php");
include("../function/function.php");
include("../function/connect.php");

// Переместил подключение к базе данных connect.php в начало файла
?>

<!-- Здесь будет контент -->
<section class="page">
    <div class="container p-3">
        <h1 class="text-center mb-3 text-success-emphasis display-1">Личный кабинет</h1>
    </div>
</section>



<form action="/admin/controllers/login.php" method="post" class="m-auto">
    <!-- ... ваша форма входа ... -->
</form>

<?php
if (!isset($_SESSION['login'])) {
    header("Location: /auth/");
    exit;
}
?>

<!-- Добавлен закрывающий тег </section> для второго блока -->
<section class="page">
    <div class="container p-3">
        <?php
        if (isset($_GET['message'])) {
            echo "<div class='border border-danger text-danger text-center pt-4 pb-4 mb-3'>{$_GET['message']}</div>";
        }
        ?>
        <h1>Личный кабинет</h1>
        <?php
        echo fnGetProfile($connect, $_SESSION['login']);
        echo fnGetCardProfile($connect, $_SESSION['login']);
        ?>
    </div>
</section>

<!-- Перемещена форма подачи заявления внутрь третьего блока -->
<form action="/admin/controllers/add_application.php" method="post" enctype="multipart/form-data" class="m-auto">
    <div class="mb-3">
        <label for="number" class="form-label fs-5">Государственный регистрационный номер автомобиля</label>
        <input type="text" class="form-control shadow-sm p-3 rounded-pill" id="number" name="number">
    </div>
    <div class="mb-3">
        <label for="message" class="form-label fs-5">Описание нарушения</label>
        <textarea class="form-control shadow-sm p-3 rounded-5" id="message" name="message" rows="5"></textarea>
    </div>
    <input type="submit" class="btn btn-success mb-3 mt-3 w-100 shadow-sm p-3 fs-2 rounded-pill fw-bold"
        value="Подать заявление">
</form>



<?php

function fnGetProfile($connect, $login)
{
    $sql = sprintf("SELECT `surname`, `name`, `patronymic`, `phone` FROM `user` WHERE `login` = '%s'", $login);
    if (!$result = $connect->query($sql)) {
        echo "Ошибка получения данных";
    }
    $row = $result->fetch_assoc();
    $data = sprintf('<p><span class="fw-semibold">Фамилия:</span> %s</p>
    <p><span class="fw-semibold">Имя:</span> %s</p>
    <p><span class="fw-semibold">Отчество:</span> %s</p>
    <p><span class="fw-semibold">Телефон:</span> %s</p>',
        $row["surname"], $row["name"], $row["patronymic"], $row["phone"]);
    return $data;
}

function fnGetCardProfile($connect, $login)
{
    $select = "SELECT `user_id` FROM `user` WHERE `login` = '" . $login . "'";
    $select_result = $connect->query($select);
    $select_row = $select_result->fetch_assoc();
    $id = $select_row['user_id'];
    $data = '<div class="cards">';
    $sql = sprintf("SELECT `number`, `number_car`, `message`, `status` FROM `application` INNER JOIN `user` ON `application`.`user_id` = `user`.`user_id` WHERE `application`.`user_id` = '%s' ORDER BY `application_id` DESC", $id);

    if (!$result = $connect->query($sql)) {
        echo "Ошибка получения данных";
    }

    // Добавлена проверка на наличие данных перед выполнением цикла
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            // ... ваш код для формирования карточек профиля
        }
    } else {
        echo "Нет данных для отображения";
    }

    $data .= "</div>";
    return $data;
}

?>

<?php
include("../inc/footer.php");
?>

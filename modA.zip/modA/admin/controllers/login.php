<?php
session_start();
include('../../function/connect.php');

if (empty($_POST['login']) || empty($_POST['password'])) {
    header("Location: /auth/index.php?message=Введите логин и пароль");
    exit;
}
// Используем подготовленные запросы для избежания SQL-инъекций
$sql = "SELECT * FROM `user` WHERE `login` = ? AND `password` = ?";
$stmt = $connect->prepare($sql);
$stmt->bind_param("ss", $_POST['login'], $_POST['password']);
$stmt->execute();
$result = $stmt->get_result();
$stmt->close();

// Проверяем результат запроса
if ($result->num_rows) {
    $row = $result->fetch_assoc();
    $_SESSION['login'] = $row['login'];
    $_SESSION['role'] = $row['role'];
    header("Location: /profile/");
    exit;
} else {
    header("Location: /auth/index.php?message=Некорректный логин или пароль");
    exit;
}
?>

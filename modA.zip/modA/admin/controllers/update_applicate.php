<?php
include(__DIR__ . '/../../function/connect.php');


if (isset($_GET['action'])) {
    switch ($_GET['action']) {
        case 'success':
            $sql = "UPDATE `application` SET `status`='Подтвержден' WHERE `application_id` = ?";
            $stmt = $connect->prepare($sql);
            $stmt->bind_param("s", $_GET['id']);
            $stmt->execute();
            $stmt->close();
            header("Location: /admin/");
            break;

        case 'cancel':
            $sql = "UPDATE `application` SET `status`='Отменен' WHERE `application_id` = ?";
            $stmt = $connect->prepare($sql);
            $stmt->bind_param("s", $_GET['id']);
            $stmt->execute();
            $stmt->close();
            header("Location: /admin/");
            break;
    }
}
?>

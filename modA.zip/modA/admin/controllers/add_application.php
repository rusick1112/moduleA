<?php
session_start();
include(__DIR__ . '/../../function/connect.php');


// Проверяем, авторизован ли пользователь
if (!isset($_SESSION['login'])) {
    header("Location: /login.php"); // Перенаправляем на страницу входа, если не авторизован
    exit;
}

// Используем подготовленные запросы для избежания SQL-инъекций
$select = "SELECT `user_id` FROM `user` WHERE `login` = ?";
$stmt = $connect->prepare($select);
$stmt->bind_param("s", $_SESSION['login']);
$stmt->execute();
$select_result = $stmt->get_result();
$stmt->close();

$select_row = $select_result->fetch_assoc();
$id_user = $select_row['user_id'];

// Генерируем случайный номер
$chars = '0123456789';
$number = substr(str_shuffle($chars), 0, 5);

// Используем подготовленные запросы для избежания SQL-инъекций
$sql = "INSERT INTO `application`(`application_id`, `user_id`, `number`, `status`, `number_car`, `message`) VALUES (NULL, ?, ?, 'Новый', ?, ?)";
$stmt = $connect->prepare($sql);
$stmt->bind_param("ssss", $id_user, $number, $_POST['number'], $_POST['message']);
$stmt->execute();
$stmt->close();

header("Location: /profile/");
exit;
?>

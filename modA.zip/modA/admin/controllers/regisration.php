<?php
session_start();
include('../../function/connect.php');

// Проверяем, отправлены ли необходимые данные
if (empty($_POST['surname']) || empty($_POST['name']) || empty($_POST['patronymic']) ||
    empty($_POST['login']) || empty($_POST['email']) || empty($_POST['phone']) || empty($_POST['password'])) {
    echo "Ошибка добавления данных";
    exit;
}

// Используем подготовленные запросы для избежания SQL-инъекций
$sql = "INSERT INTO `user`(`user_id`, `surname`, `name`, `patronymic`, `login`, `email`, `phone`, `password`, `role`) VALUES
(NULL, ?, ?, ?, ?, ?, ?, ?, 'Пользователь')";

$stmt = $connect->prepare($sql);
$stmt->bind_param("sssssss", $_POST['surname'], $_POST['name'], $_POST['patronymic'], $_POST['login'], $_POST['email'], $_POST['phone'], $_POST['password']);

if (!$stmt->execute()) {
    echo "Ошибка добавления данных";
    $stmt->close();
    exit;
}

$stmt->close();

$_SESSION['login'] = $_POST['login'];
$_SESSION['role'] = "Пользователь";
header("Location: /profile/");
exit;
?>

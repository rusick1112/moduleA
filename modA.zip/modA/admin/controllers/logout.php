<?php
session_start();

// Проверяем, существует ли сессия перед удалением
if (isset($_SESSION['login'])) {
    unset($_SESSION['login']);
}

if (isset($_SESSION['role'])) {
    unset($_SESSION['role']);
}

// Дополнительно можем завершить сессию с помощью session_destroy()
// session_destroy();

header("Location: /");
exit;
?>

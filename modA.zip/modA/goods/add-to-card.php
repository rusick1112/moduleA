<?php
include("../inc/header.php");
?>

<body class="bg-success">

<header class="container p-3 text-center">
    <h1 class="mt-3 mb-4 text-white display-1">Корзина</h1>
</header>

<main class="container p-2 mb-5 text-center">
    <div class="row">
        <div class="col-md-8">
            <!-- Вывод добавленных товаров -->
            <?php
            // Здесь будет код для вывода товаров в корзине
            // Вы можете использовать сессии или базу данных для хранения товаров в корзине
            // Каждый товар должен содержать кнопку удаления
            // Пример:
            ?>
            <div class="card mb-3">
                <div class="card-body">
                    <h5 class="card-title">Товар 1</h5>
                    <p class="card-text">Цена: 5000 руб.</p>
                    <button class="btn btn-danger">Удалить</button>
                </div>
            </div>

            <!-- Добавьте аналогичные карточки для каждого товара в корзине -->
        </div>
        <div class="col-md-4">
            <!-- График с категориями -->
            <div class="card mb-3">
                <div class="card-body">
                    <!-- Здесь будет код для отображения графика с категориями в процентах -->
                </div>
            </div>

            <!-- Счетчик общей цены -->
            <div class="card mb-3">
                <div class="card-body">
                    <h5 class="card-title">Общая цена</h5>
                    <!-- Здесь будет код для отображения общей цены всех товаров в корзине -->
                </div>
            </div>

            <!-- Кнопка "Купить" -->
            <button class="btn btn-success btn-lg btn-block">Купить</button>
        </div>
    </div>
</main>

<?php
include("../inc/footer.php");
?>
</body>
</html>
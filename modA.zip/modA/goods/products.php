  <?php
// include ("../function/connect.php"); 
//  $goods = mysqli_query ($connect, "SELECT * FROM `goods`");
//  $goods = mysqli_fetch_all ($goods); 

 include("../inc/header.php");
 ?>

 <!-- <body class="bg-success">

 <header class="container p-3 text-center">
     <h1 class="mt-3 mb-4 text-white display-1">Товары</h1>
 </header>

 <table>
     <?php // НАЧАЛО ПЕРЕБОРА ЭЛЕМЕНТОВ ТАБЛИЦЫ
         foreach ($goods as $item) {
     ?>
     <tr>
         <td><?php echo $item[1] ?></td>
         <td><?php echo $item[2] ?></td>
     </tr>
     <?php // КОНЕЦ ПЕРЕБОРА
         };
     ?>
 </table> -->

<main class="container p-2 mb-5 text-center">
    <div class="row">

        <?php
       // Массив товаров
        $products = [
            [
                'category' => 'Пылесосы',
                'name' => 'Dyson V15 Detect Absolute',
                'price' => 60000,
                'link' => '/add-to-cart.php?product=dyson_v15',
                'image' => 'https://img1.festima.ru/2/1.9WcrRba6WY4d7JuLTVb0ePPmX4qfZlFMmuZdhp_uWw.Q62GF0bl90Ys4yoHgmfp8UF75Q6svigkXg2jPTbHtNM', 
            ],
            [
                'category' => 'Фены',
                'name' => 'Dyson Supersonic',
                'price' => 50000,
                'link' => '/add-to-cart.php?product=dyson_supersonic',
                'image' => 'https://avatars.mds.yandex.net/i?id=fa4a3151aa4bc98453637f9d87f478b0420d9585-9871231-images-thumbs&n=13',
            ],
            [
                'category' => 'Ноутбуки',
                'name' => 'Huawei Matebook D15',
                'price' => 63000,
                'link' => '/add-to-cart.php?product=huawei_matebook_d15',
                'image' => 'https://images.says.com/uploads/story_source/source_image/754031/7e91.jpg',
            ],
            [
                'category' => 'Книга',
                'name' => 'Айзек Азимов Я, Робот',
                'price' => 350,
                'link' => '/add-to-cart.php?product=I_Robot',
                'image' => 'https://kulturologia.ru/files/u27045/9fantas.jpg',
            ],
            [
                'category' => 'Книга',
                'name' => 'Джордж Оруэлл 1984',
                'price' => 350,
                'link' => '/add-to-cart.php?product=1984',
                'image' => 'https://www.amic.ru/images/news/news/383190_size1.jpg',
            ],
            [
                'category' => 'Касметика',
                'name' => 'Зеркало косметическое белый Frost',
                'price' => 450,
                'link' => '/add-to-cart.php?product=zerkalo',
                'image' => 'https://avatars.mds.yandex.net/i?id=2a0000018d2e181a134d7e44c085b52d7961-939652-fast-images&n=13',
            ],
        ];

        // Генерация карточек для каждого товара
        foreach ($products as $product) {
            generateProductCard($product['category'], $product['name'], $product['price'], $product['link'], $product['image']);
        }
        ?>

    </div>
</main>

<?php
include("../inc/footer.php");
?>

<?php
// Функция для генерации карточки товара
function generateProductCard($category, $name, $price, $link, $image)
{
    echo '<div class="col-md-4 mb-4">';
    echo '<div class="card">';
    echo '<div class="card-body">';
    echo '<h5 class="card-title">' . $category . ': ' . $name . '</h5>';
    echo '<img src="/images/' . $image . '" class="card-img-top" alt="' . $name . '">';
    echo '<p class="card-text">Цена: ' . number_format($price, 0, ',', ' ') . ' руб.</p>';
    echo '<a href="' . $link . '" class="btn btn-primary">Добавить в корзину</a>';
    echo '</div>';
    echo '</div>';
    echo '</div>';
}
?>
</body>
</html>

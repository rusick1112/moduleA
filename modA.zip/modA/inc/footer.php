<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!-- Добавлено подключение jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <link rel="stylesheet" href="/assets/bootstrap/css/bootstrap.min.css">
</head>
<body>
    <!-- Добавлен открывающий тег <main> -->
    <main>
   <!-- footer.php -->

<footer class="bg-dark text-light">
    <div class="container-fluid p-3 pt-3">
        <p>&copy; Ягодкам.Нет<br>2024-2025</p>
    </div>
</footer>

    </main>
    <!-- Перемещено подключение Bootstrap JS после подключения jQuery -->
    <script src="/assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>

<?php

function fnGetCardAdmin() {
    global $connect;

    $data = '<div class="cards">';
    $sql = "SELECT `application_id`, `surname`, `name`, `patronymic`, `number`, `number_car`, `message`, `status` FROM `application` INNER JOIN `user` ON `application`.`user_id` = `user`.`user_id` ORDER BY `application_id` DESC";

    if (!$result = $connect->query($sql)) {
        echo "Ошибка получения данных";
    }

    while ($row = $result->fetch_assoc()) {
        // Ваш код для формирования карточек администратора
        // Включите Фамилию, Имя, Отчество в вывод

        $data .= sprintf('<div class="card w-100 mb-3 mt-3 text-muted">
            <div class="card-body">
                <h5 class="card-title">Нарушение №%s</h5>
                <p class="mb-1"><span class="fw-semibold">Фамилия:</span> %s</p>
                <p class="mb-1"><span class="fw-semibold">Имя:</span> %s</p>
                <p class="mb-1"><span class="fw-semibold">Отчество:</span> %s</p>
                <p class="mb-1"><span class="fw-semibold">Статус:</span> %s</p>
                <p class="mb-1"><span class="fw-semibold">Гос номер авто:</span> %s</p>
                <p class="card-text">%s</p>
            </div>
            <div class="d-flex align-items-center justify-content-between cards_btn">
                <a href="controllers/update_applicate.php?id=%s&action=success" class="btn mb-3 mt-3 shadow-sm p-3 rounded-pill fw-bold btn-success">Подтвердить</a>
                <a href="controllers/update_applicate.php?id=%s&action=cancel" class="btn mb-3 mt-3 shadow-sm p-3 rounded-pill fw-bold btn-outline-success border border-success m-0">Отменить</a>
            </div>
        </div>',
            $row['number'],
            $row['surname'],
            $row['name'],
            $row['patronymic'],
            $row['status'],
            $row['number_car'],
            $row['message'],
            $row['application_id'],
            $row['application_id']);
    }

    $data .= "</div>";
    return $data;
}
?>
